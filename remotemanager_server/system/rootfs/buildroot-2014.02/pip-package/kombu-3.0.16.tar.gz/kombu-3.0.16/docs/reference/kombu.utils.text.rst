==========================================================
 Text utilitites - kombu.utils.text
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.text

.. automodule:: kombu.utils.text
    :members:
    :undoc-members:
