==========================================================
 Django Management - clean_kombu_messages
==========================================================

.. contents::
    :local:
.. currentmodule::
    kombu.transport.django.management.commands.clean_kombu_messages

.. automodule::
    kombu.transport.django.management.commands.clean_kombu_messages

    :members:
    :undoc-members:
