.. _ref-support:

=======
Support
=======

boto.support
------------

.. automodule:: boto.support
   :members:
   :undoc-members:

boto.support.layer1
-------------------

.. automodule:: boto.support.layer1
   :members:
   :undoc-members:

boto.support.exceptions
-----------------------

.. automodule:: boto.support.exceptions
   :members:
   :undoc-members:
