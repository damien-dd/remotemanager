.. ref-cloudsearch2

===========
Cloudsearch
===========

boto.cloudsearch2
-----------------

.. automodule:: boto.cloudsearch2
   :members:
   :undoc-members:

boto.cloudsearch2.domain
------------------------

.. automodule:: boto.cloudsearch2.domain
   :members:
   :undoc-members:

boto.cloudsearch2.layer1
------------------------

.. automodule:: boto.cloudsearch2.layer1
   :members:
   :undoc-members:

boto.cloudsearch2.layer2
------------------------

.. automodule:: boto.cloudsearch2.layer2
   :members:
   :undoc-members:

boto.cloudsearch2.optionstatus
------------------------------

.. automodule:: boto.cloudsearch2.optionstatus
   :members:
   :undoc-members:

boto.cloudsearch2.search
------------------------

.. automodule:: boto.cloudsearch2.search
   :members:
   :undoc-members:

boto.cloudsearch2.document
--------------------------

.. automodule:: boto.cloudsearch2.document
   :members:
   :undoc-members:
